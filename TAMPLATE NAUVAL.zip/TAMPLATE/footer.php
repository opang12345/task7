  <!-- Footer -->
      <div class="container-fluid footer ">
         <div class="row">
            <div class="col-xl-2 col-md-8 offset-md-1 col-sm-12 ">
               <p>
                  <a href="about.html">About</a><br>
                  <a href="story.html">Story</a><br>
                  <a href="services.html">Services</a><br>
                  <a href="contacts.html">Contacts</a><br>
               </p>
            </div>
            <div class="col-xl-2 col-md-8 offset-md-1 col-sm-12 ">
               <p>
                  <a href="index.html">Privacy</a><br>
                  <a href="index.html">Termini di utilizzo </a><br>
                  <a href="index.html">Note legali </a><br>
                  <a href="index.html">Credits</a><br>
               </p>
            </div>
            <div class="col-xl-2 col-md-8 offset-md-1 col-sm-12">
               <p>
                  FONDAZIONE SENECA<br>
                  Via Longhena 116<br>
                  00060 - Nazzano (ROMA)<br>
                  TEL. +39 0327 8523827
               </p>
            </div>
         </div>
      </div>
      <!-- End Footer -->
      <!-- Javascript -->
      <script src="vendor/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
      <script src="vendor/wow/wow.js"></script>
      <script src="js/script.js"></script>
      <script>
         new WOW().init();
      </script>
      <!-- End Javascript -->
   </body>
</html>